//importation de la librairie express
const express = require('express');
const app = express()//instanciation de la librairie express 
//importation des données de parkings.json
const parkings = require('./parkings.json');
const reservations=require('./reservations.json');
//ajout du middleware pour lecture du body de la requete lorsqu'on realise un post
app.use(express.json()); 

//definition des routes GET parking
app.get('/parkings',(req,res)=>{
   // res.send("Liste des parkings");//renvoie un type texte
    res.status(200).json(parkings);//renvois un type json
});
app.get('/parkings/:id',(req,res)=>{
   // res.send("Liste des parkings en particulier à partir de ID");
   //recupere l'id pour afficher uniquement le parking qui correspond
  //req.params.id renvoie un string
   const id =parseInt(req.params.id);//recupere l'id demandé par le client 
   const parking= parkings.find(parking=>parking.id === id);//recherche dans parkings celui qui correspond à l'id entrée
   res.status(200).json(parkings);
});

//DEFINITIONS DES ROUTES GET DE RESERVATION
app.get('/parkings/:id/reservations',(req,res)=>{
    res.status(200).json(reservations);
});
app.get('/parkings/:id/reservations/:idReservation',(req,res)=>{
    const id =parseInt(req.params.id);//recupere l'id demandé par le client 
    const reservation= reservations.find(reservation=>reservation.id === id);//recherche dans parkings celui qui correspond à l'id entrée
    res.status(200).json(reservations);
});
//DEFINITIONS DES ROUTES POST DE RESERVATION
app.post('/parkings/:id/reservations',(req,res)=>{
    reservations.push(req.body);
    res.status(200).json(reservations);
});
//DEFINITIONS DES PUT RESERVATION
app.put('/parking/:id/reservations/:idReservation',(req,res)=>{
    const id= parseInt(req.params.id);
    let reservation= reservations.find(reservation=>reservation.id === id);
    
    reservation.city=req.body.city,
    reservation.clientName=req.body.clientName,
    reservation.vehicle=req.body.vehicle,
    reservation.licensePlate=req.body.licensePlate,
    reservation.checkin=req.body.checkin,
    reservation.checkout=req.body.checkout,
    res.status(200).json(reservations);
});
//DELETE RESERVATION
app.delete('/parking/:id/reservations/:idReservation',(req,res)=>{
    const id = parseInt(req.params.id);
    let reservation=reservations.find(reservation=>reservation.id===id);
    reservations.splice(reservations.indexOf(reservation),1);
    res.status(200).json(reservations);
    });
//DEFINITION DES ROUTES POST POUR CREER UN ELEMENT
app.post('/parkings',(req,res)=>{
    parkings.push(req.body);
    res.status(200).json(parkings);
});

//DEFINITION DES ROUTES PUT POUR MODIFIER UN ELEMENT
app.put('/parkings/:id',(req,res)=>{
    const id= parseInt(req.params.id);
    let parking= parkings.find(parking=>parking.id === id);
    parking.name=req.body.name,
    parking.city=req.body.city,
    parking.type=req.body.type,
    res.status(200).json(parkings);
});
//DEFINITION DES ROUTES DELETE POUR MODIFIER UN ELEMENT
app.delete('/parkings/:id',(req,res)=>{
const id = parseInt(req.params.id);
let parking=parkings.find(parking=>parking.id===id);
parkings.splice(parkings.indexOf(parking),1);
res.status(200).json(parkings);
});
//lancer le serveur
app.listen(8080,() => {
   console.log("serveur lancé et à l'écoute"); 
});

